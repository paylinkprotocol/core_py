class PayLinkProtocolError(Exception):
    pass
